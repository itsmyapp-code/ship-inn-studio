declare module 'rss' {
  const RSS: any;
  export default RSS;
}