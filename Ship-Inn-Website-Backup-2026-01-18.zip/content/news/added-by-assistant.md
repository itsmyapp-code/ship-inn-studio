---
title: "Assistant-added: New sample post"
publishedDate: "2025-12-07"
coverImage: "/images/news/sample.jpg"
---

Welcome — this is a sample news post added by the assistant so you can see content appear on the site.

Edit or replace this file in `content/news/` or use Keystatic Cloud to create nicer posts.
