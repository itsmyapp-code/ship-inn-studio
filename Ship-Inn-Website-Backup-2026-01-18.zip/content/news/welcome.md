---
title: "Welcome to The Ship Inn News"
publishedDate: "2025-12-07"
coverImage: "/images/news/sample.jpg"
---

Welcome to the news feed for The Ship Inn, Porlock Weir. This is a sample Keystatic entry created during migration.

- Enjoy the harbour views
- Bookings open for summer
