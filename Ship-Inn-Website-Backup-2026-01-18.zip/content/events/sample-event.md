---
title: "Lobster Night"
eventDate: "2026-01-15"
location: "The Ship Inn Dining Room"
---

Join us for Lobster Night with live music and seasonal sides.
