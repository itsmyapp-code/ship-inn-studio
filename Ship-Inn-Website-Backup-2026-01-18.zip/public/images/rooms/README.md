# Room Photos
Place individual room photos here.

Examples:
- harbour-room-bed.jpg
- harbour-room-view.jpg
- weir-room-bathroom.jpg
- cottage-room-interior.jpg

Recommended size: 800x600px or larger
File format: .jpg (optimized for web, under 500KB each)