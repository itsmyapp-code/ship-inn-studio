# Food & Restaurant Photos
Place photos of food, dining areas, and bar here.

Examples:
- restaurant-interior.jpg
- bar-area.jpg
- local-seafood-dish.jpg
- traditional-pub-meal.jpg
- breakfast-spread.jpg

Perfect for: Food & Drink page, Homepage food sections
Recommended size: 800x600px