# Gallery Images
Place high-quality photos for the main gallery page here.

Mix of:
- Best room photos
- Exterior shots
- Food photography
- Location scenery
- Guest experience moments

These should be your very best photos!
Recommended size: 1200x800px, optimized for web