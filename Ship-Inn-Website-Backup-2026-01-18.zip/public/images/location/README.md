# Location & Area Photos
Place photos of Porlock Weir and surrounding area here.

Examples:
- porlock-weir-harbour.jpg
- porlock-weir-village.jpg
- porlock-weir-beach.jpg
- exmoor-coastal-path.jpg
- local-attractions.jpg

Perfect for: Things to Do page, Location sections
Shows guests what they can explore nearby