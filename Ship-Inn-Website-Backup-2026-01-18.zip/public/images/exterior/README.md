# Exterior Photos
Place photos of The Ship Inn building exterior here.

Examples:
- ship-inn-front-view.jpg
- ship-inn-side-entrance.jpg
- ship-inn-garden-area.jpg
- ship-inn-signage.jpg
- ship-inn-sunset.jpg

Perfect for: Homepage hero, About section, Gallery
Recommended size: 1200x800px or larger