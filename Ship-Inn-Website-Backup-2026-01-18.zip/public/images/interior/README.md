# Interior Common Areas
Place photos of pub, restaurant, lounge, and common areas here.

Examples:
- pub-interior.jpg
- restaurant-dining-room.jpg
- reception-area.jpg
- lounge-seating.jpg
- fireplace-area.jpg

Perfect for: Homepage, About sections
Shows the atmosphere and character of The Ship Inn