---
title: 'The Ship Inn'
status: 'published'
author:
  name: ''
  picture: 'https://avatars.githubusercontent.com/u/220572112?v=4'
slug: 'we-are-hiring'
description: ''
coverImage: ''
publishedAt: '2026-01-08T18:41:10.352Z'
---

![](/images/612079066_122118113313039461_5578543549280750358_n-cwND.jpg)

### We’re gearing up for a busy season at The Ship Inn, Porlock Weir and are hiring across most departments. We’re currently looking for:

- Front of House Staff

- Kitchen Porter

- Chef de Partie

  If you enjoy hospitality and want to be part of a friendly coastal team, we’d love to hear from you.

Please email Michelle at [hello@theshipinnporlockweir.co.uk](mailto:hello@theshipinnporlockweir.co.uk)

or call 01643 863288 for more details.